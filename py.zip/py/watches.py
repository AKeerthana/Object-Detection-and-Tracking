import numpy as np
import cv2
from collections import deque
import argparse

ap = argparse.ArgumentParser()
ap.add_argument("-v", "--video",help="path to the (optional) video file")
ap.add_argument("-b", "--buffer", type=int, default=64,help="max buffer size")
args = vars(ap.parse_args())

pts = deque(maxlen=4096)
counter = 0
(dX, dY) = (0, 0)
direction = ""
if not args.get("video", False):
	cap = cv2.VideoCapture(0)

# otherwise, grab a reference to the video file
else:
	cap = cv2.VideoCapture(args["video"])

#this is the cascade we just made. Call what you want
watch_cascade = cv2.CascadeClassifier('watch.xml')

#cap = cv2.VideoCapture(0)

while True:
    ret, img = cap.read()
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    #faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    print ("HI?????")
    # add this
    # image, reject levels level weights.
    watches = watch_cascade.detectMultiScale(gray, 50, 50)
    print ("HI#######")
    # add this
    for (x,y,w,h) in watches:
        print ("HI1111111")
        r=cv2.rectangle(img,(x,y),(x+w,y+h),(255,255,0),2)
        cnts = cv2.findContours(gray.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)[-2]
        center= None
        print ("HI*******")
        if len(cnts) > 0:
            c = max(cnts, key=cv2.contourArea)
            ((a, b), radius) = cv2.minEnclosingCircle(c)
            M = cv2.moments(c)
            center = (int(M["m10"] / M["m00"]), int(M["m01"] / M["m00"]))
            print ("HI&&&&&&&&&")
            if radius > 10:
                ##cv2.circle(r, (int(a), int(b)), 1,(0, 255, 255), 1)
                #cv2.circle(r, (int((x+w)/2),int((y+h)/2)), 5, (0, 0, 255), -1)
                pts.appendleft(center)
                print ("HI++++++++++")
        for i in np.arange(1, len(pts)):
		# if either of the tracked points are None, ignore
		# them
            if pts[i - 1] is None or pts[i] is None:
                continue
            thickness = int(np.sqrt(4096/ float(i + 1)) * 2.5)
            cv2.line(img, pts[i - 1], pts[i], (0, 0, 255), thickness)
    cv2.imshow("Frame", img)
    key = cv2.waitKey(1) & 0xFF
    counter += 1
    if key == ord("q"):
        break
cap.release()
cv2.destroyAllWindows()
		# check to see if enough points have been accumulated in
		# the buffer
'''
            if counter >= 10 and i == 1 and pts[-10] is not None:
			# compute the difference between the x and y
			# coordinates and re-initialize the direction
			# text variables
                dX = pts[-10][0] - pts[i][0]
                dY = pts[-10][1] - pts[i][1]
                (dirX, dirY) = ("", "")
 
			# ensure there is significant movement in the
			# x-direction
                if np.abs(dX) > 20:
                    dirX = "East" if np.sign(dX) == 1 else "West"
 
			# ensure there is significant movement in the
			# y-direction
                if np.abs(dY) > 20:
                    dirY = "North" if np.sign(dY) == 1 else "South"
 
			# handle when both directions are non-empty
                if dirX != "" and dirY != "":
                    direction = "{}-{}".format(dirY, dirX)
 
			# otherwise, only one direction is non-empty
                else:
                    direction = dirX if dirX != "" else dirY
'''
# otherwise, compute the thickness of the line and
		# draw the connecting lines
            #thickness = int(np.sqrt(4096/ float(i + 1)) * 2.5)
            #cv2.line(img, pts[i - 1], pts[i], (0, 0, 255), thickness)
 
	# show the movement deltas and the direction of movement on
	# the frame
        #cv2.putText(img, direction, (10, 30), cv2.FONT_HERSHEY_SIMPLEX,
    #0.65, (0, 0, 255), 3)
        #cv2.putText(img, "dx: {}, dy: {}".format(dX, dY),
    #(10, img.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX,
#    0.35, (0, 0, 255), 1)
 
	# show the frame to our screen and increment the frame counter
#    cv2.imshow("Frame", img)
#    key = cv2.waitKey(1) & 0xFF
#    counter += 1
 
	# if the 'q' key is pressed, stop the loop
#    if key == ord("q"):
#        break
 
# cleanup the camera and close any open windows
#cap.release()
#cv2.destroyAllWindows()
