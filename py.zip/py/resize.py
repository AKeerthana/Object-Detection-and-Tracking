import urllib.request
import cv2
import numpy as np
import os

img=cv2.imread("a.jpg")
resized_img=cv2.resize(img,(50,50))
cv2.imwrite("b.jpg",resized_img)

